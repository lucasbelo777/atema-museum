#ifndef CADASTRO_OBRA_H_INCLUDED
#define CADASTRO_OBRA_H_INCLUDED

typedef struct {
    int id;
    char tema[50], obra_1[255], obra_2[255], obra_3[255], descricao_1[255], descricao_2[255], descricao_3[255];
} Registro;

#endif // CADASTRO_OBRA_H_INCLUDED
